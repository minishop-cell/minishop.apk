const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('minishopDesktop', {
  listPrinters: () => ipcRenderer.invoke('printers'),
  print: (opts) => ipcRenderer.invoke('print', opts || {})
});
