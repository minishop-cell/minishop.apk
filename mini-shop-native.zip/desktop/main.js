const { app, BrowserWindow, Menu, shell, ipcMain, dialog } = require('electron');
const path = require('path');

if (!app.requestSingleInstanceLock()) {
  app.quit();
} else {
  let win = null;

  // Small chooser used when the app asks for a serial port or USB printer.
  function pick(title, items) {
    if (!items.length) return '';
    if (items.length === 1) return items[0].id;
    const shown = items.slice(0, 8);
    const i = dialog.showMessageBoxSync(win, {
      type: 'question', title, message: title,
      buttons: shown.map((x) => x.label).concat(['Cancel']),
      cancelId: shown.length, defaultId: 0
    });
    return i < shown.length ? shown[i].id : '';
  }

  ipcMain.handle('printers', async () => {
    if (!win) return [];
    const list = await win.webContents.getPrintersAsync();
    return list.map((p) => ({ name: p.name, displayName: p.displayName || p.name }));
  });

  ipcMain.handle('print', (event, opts) => new Promise((resolve) => {
    if (!win) return resolve({ ok: false, why: 'No window' });
    win.webContents.print({
      silent: !!opts.silent,
      deviceName: opts.deviceName || '',
      printBackground: true,
      margins: { marginType: 'none' }
    }, (ok, why) => resolve({ ok, why }));
  }));

  app.on('second-instance', () => {
    if (win) { if (win.isMinimized()) win.restore(); win.focus(); }
  });

  function createWindow() {
    win = new BrowserWindow({
      width: 1280, height: 820, minWidth: 900, minHeight: 600,
      title: 'Mini Shop', backgroundColor: '#f4f7fb',
      webPreferences: {
        contextIsolation: true,
        sandbox: true,
        preload: path.join(__dirname, 'preload.js')
      }
    });

    const ses = win.webContents.session;
    // Camera (barcode scanning) and printer access for this app only.
    ses.setPermissionCheckHandler((wc, permission) => ['media', 'serial', 'usb'].includes(permission));
    ses.setPermissionRequestHandler((wc, permission, callback) => callback(['media', 'serial', 'usb'].includes(permission)));
    ses.setDevicePermissionHandler((details) => details.deviceType === 'serial' || details.deviceType === 'usb');
    ses.on('select-serial-port', (event, portList, wc, callback) => {
      event.preventDefault();
      callback(pick('Choose the printer port', portList.map((p) => ({ label: (p.displayName || p.portName) + ' (' + p.portName + ')', id: p.portId }))));
    });
    ses.on('select-usb-device', (event, deviceList, wc, callback) => {
      event.preventDefault();
      callback(pick('Choose the USB printer', deviceList.map((d) => ({ label: (d.productName || 'USB device') + ' (' + d.vendorId + ':' + d.productId + ')', id: d.deviceId }))));
    });

    win.loadFile(path.join(__dirname, 'www', 'index.html'));
    win.webContents.setWindowOpenHandler(({ url }) => {
      if (/^(https?:|mailto:|tel:)/i.test(url)) shell.openExternal(url);
      return { action: 'deny' };
    });
    win.webContents.on('will-navigate', (event, url) => {
      if (!/^file:/i.test(url)) {
        event.preventDefault();
        if (/^(https?:|mailto:|tel:)/i.test(url)) shell.openExternal(url);
      }
    });
    win.on('closed', () => { win = null; });
  }

  app.whenReady().then(() => {
    if (process.platform === 'win32') Menu.setApplicationMenu(null);
    createWindow();
    app.on('activate', () => { if (BrowserWindow.getAllWindows().length === 0) createWindow(); });
  });
  app.on('window-all-closed', () => app.quit());
}
