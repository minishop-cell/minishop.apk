# Mini Shop – real apps (Android, Windows, Mac)

GitHub builds the apps for you, free, in the cloud. You only need a phone browser.

## One-time setup (about 15 minutes)

1. **Create a new repository** on GitHub (for example `mini-shop-app`). Public is fine. Tick "Add a README".
2. **Save the signing key as a secret** (this keeps your Android data safe when you update the app):
   - Repo > Settings > Secrets and variables > Actions > New repository secret
   - Name: `ANDROID_KEYSTORE_B64`
   - Value: the whole text from the file `ANDROID_KEYSTORE_B64.txt` (do NOT upload that file to the repo)
3. **Add the build recipe**: Repo > Add file > Create new file.
   In the name box type `.github/workflows/build.yml` (typing the slashes makes the folders).
   Paste the whole content of `workflow/build.yml` (it is inside the zip, and also in your downloads), then Commit.
4. **Upload the project**: Repo > Add file > Upload files. Upload ONE file: `mini-shop-native.zip` (do not unzip it). Commit.
5. The build starts by itself. Open the **Actions** tab to watch (about 10 minutes). Green tick = done.
6. Open **Releases** (right side of the repo page). Download:
   - `MiniShop-Android.apk` for Android
   - `MiniShop-Windows-Setup.exe` for Windows
   - `MiniShop-Mac-arm64.dmg` (newer Macs) or `MiniShop-Mac-x64.dmg` (older Intel Macs)

If a build shows a red cross, open it, copy the last red error lines and send them to me.

## Installing

- **Android**: open the APK. Android will ask to allow installs from your browser or Files app: allow it. Google Play Protect may warn about an unknown app: tap "Install anyway".
- **Windows**: run the installer. If it says "Windows protected your PC", tap More info > Run anyway (the app is not signed with a paid certificate).
- **Mac**: open the dmg and drag Mini Shop to Applications. The first time, right-click the app > Open. If it says the app is damaged, open Terminal and run: `xattr -cr "/Applications/Mini Shop.app"`
- **iPhone / iPad**: a real iPhone app needs a Mac and Apple's $99/year developer account. Until then use Safari > Share > Add to Home Screen on your normal website link.

## Where the data lives

Inside each installed app, on that device only. It survives app updates. It is deleted if you uninstall, so back up first.

## Moving to a new device

- **With a file**: Settings > Backup & restore > Download backup. On Android a share sheet opens: send the file to yourself (WhatsApp, email, Drive). On the new device install the app, then Settings > Restore backup.
- **With the cloud**: see below. Upload on the old device, sign in and restore on the new one.
- Admin and temporary-user logins are not included. Create the admin account again on the new device.

## Moving your current website data into the app

Open your old website version, Settings > Download backup. Install the new app, then Restore backup.

## Turning on cloud backup (optional, free)

1. Go to console.firebase.google.com and create a project (turn off Google Analytics).
2. Build > Authentication > Get started > Sign-in method > Email/Password > Enable.
3. Build > Firestore Database > Create database > Production mode > pick a location.
4. Firestore > Rules tab > replace everything with the text below > Publish:

```
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /backups/{doc} {
      allow read, write: if request.auth != null && doc.matches(request.auth.uid + '_.*');
    }
  }
}
```

5. Project settings (gear icon) > General > Your apps > add a Web app (the </> icon). Copy `apiKey` and `projectId`.
6. In your repo: Add file > Create new file. Name it `cloud-config.js` (in the main folder, next to the zip). Paste this, with your two values between the quotes, then Commit:

```
window.CLOUD_CONFIG = {
  apiKey: "PASTE_YOUR_API_KEY",
  projectId: "PASTE_YOUR_PROJECT_ID"
};
```

   The build starts again by itself and the new apps have cloud backup switched on.
7. In the app: Settings > Cloud backup > Create cloud account (any email and a password). Then "Upload backup now". Turn on "Auto backup" to upload about once a day.

Each person with the app uses the same Firebase project but their own cloud account, and can only see their own backup.

## Updating the apps later

Upload a new `mini-shop-native.zip` with the same name (Add file > Upload files, it replaces the old one). The build runs again and a new release appears. Install the new APK over the old one: your data stays.
