// Developer details: shown as a watermark at the bottom of the menu and on the About screen.
// Leave "name" empty to hide the watermark. Keep the quotation marks and commas.
window.DEVELOPER_INFO = {
  name: "",        // e.g. "Alex Tan"
  business: "",    // e.g. "Alex Tan Software"
  tagline: "",     // e.g. "Custom business software and support"
  phone: "",       // e.g. "+60 12-345 6789"
  whatsapp: "",    // digits only, with country code, e.g. "60123456789"
  email: "",       // e.g. "alex@example.com"
  website: "",     // e.g. "https://example.com"
  hours: ""        // e.g. "Support: Mon to Sat, 9am to 6pm"
};
