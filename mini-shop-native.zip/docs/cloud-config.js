// Cloud backup settings (optional).
// Leave both values empty to keep cloud backup switched off.
// To turn it on, create a free Firebase project and paste its web "apiKey"
// and "projectId" here. Steps are in README.md.
window.CLOUD_CONFIG = {
  apiKey: "",
  projectId: ""
};
