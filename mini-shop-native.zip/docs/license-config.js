// License settings. Leave required: false to switch the time limit off.
// To limit how long shop owners can use the app, open Developer admin in the app
// (tap the version line at the bottom of the menu 7 times), create your developer key,
// and paste its public key here with required: true. See README.md.
window.LICENSE_CONFIG = {
  required: false,
  publicKey: "",
  trialDays: 0
};
